setwd <- getwd()

library("SAScii")
library(readr)
dic_cog <- parse.SAScii(sas_ri = "PISA2012_SAS_scored_cognitive_item.sas")

cog <- read_fwf(file = "INT_COG12_S_DEC03.txt", col_positions = fwf_widths(dic_cog$width), progress = T)

colnames(cog) <- dic_cog$varname
